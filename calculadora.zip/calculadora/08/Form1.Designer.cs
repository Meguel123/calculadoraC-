﻿namespace _08
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button17 = new Button();
            button18 = new Button();
            textBox1 = new TextBox();
            button19 = new Button();
            button20 = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 16F);
            button1.Location = new Point(696, 195);
            button1.Name = "button1";
            button1.Size = new Size(125, 88);
            button1.TabIndex = 5;
            button1.Text = "^";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 16F);
            button2.Location = new Point(696, 65);
            button2.Name = "button2";
            button2.Size = new Size(125, 89);
            button2.TabIndex = 6;
            button2.Text = "+";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Font = new Font("Segoe UI", 24F);
            button3.Location = new Point(393, 315);
            button3.Name = "button3";
            button3.Size = new Size(113, 88);
            button3.TabIndex = 7;
            button3.Text = "-";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Font = new Font("Segoe UI", 16F);
            button4.Location = new Point(558, 318);
            button4.Name = "button4";
            button4.Size = new Size(103, 93);
            button4.TabIndex = 8;
            button4.Text = "÷";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Font = new Font("Segoe UI", 16F);
            button5.Location = new Point(55, 62);
            button5.Name = "button5";
            button5.Size = new Size(112, 92);
            button5.TabIndex = 9;
            button5.Text = "1";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Font = new Font("Segoe UI", 16F);
            button6.Location = new Point(230, 62);
            button6.Name = "button6";
            button6.Size = new Size(105, 92);
            button6.TabIndex = 10;
            button6.Text = "2";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.Font = new Font("Segoe UI", 16F);
            button7.Location = new Point(393, 62);
            button7.Name = "button7";
            button7.Size = new Size(113, 92);
            button7.TabIndex = 11;
            button7.Text = "3";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.Font = new Font("Segoe UI", 16F);
            button8.Location = new Point(558, 62);
            button8.Name = "button8";
            button8.Size = new Size(103, 92);
            button8.TabIndex = 12;
            button8.Text = "4";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.Font = new Font("Segoe UI", 16F);
            button9.Location = new Point(230, 195);
            button9.Name = "button9";
            button9.Size = new Size(105, 84);
            button9.TabIndex = 13;
            button9.Text = "6";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // button10
            // 
            button10.Font = new Font("Segoe UI", 16F);
            button10.Location = new Point(55, 195);
            button10.Name = "button10";
            button10.Size = new Size(112, 84);
            button10.TabIndex = 14;
            button10.Text = "5";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // button11
            // 
            button11.Font = new Font("Segoe UI", 16F);
            button11.Location = new Point(558, 195);
            button11.Name = "button11";
            button11.Size = new Size(103, 84);
            button11.TabIndex = 15;
            button11.Text = "8";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button11_Click;
            // 
            // button12
            // 
            button12.Font = new Font("Segoe UI", 16F);
            button12.Location = new Point(55, 315);
            button12.Name = "button12";
            button12.Size = new Size(112, 93);
            button12.TabIndex = 16;
            button12.Text = "9";
            button12.UseVisualStyleBackColor = true;
            button12.Click += button12_Click;
            // 
            // button13
            // 
            button13.Font = new Font("Segoe UI", 16F);
            button13.Location = new Point(393, 195);
            button13.Name = "button13";
            button13.Size = new Size(113, 84);
            button13.TabIndex = 17;
            button13.Text = "7";
            button13.UseVisualStyleBackColor = true;
            button13.Click += button13_Click;
            // 
            // button14
            // 
            button14.Font = new Font("Segoe UI", 16F);
            button14.Location = new Point(230, 315);
            button14.Name = "button14";
            button14.Size = new Size(105, 93);
            button14.TabIndex = 18;
            button14.Text = "0";
            button14.UseVisualStyleBackColor = true;
            button14.Click += button14_Click;
            // 
            // button15
            // 
            button15.Font = new Font("Segoe UI", 16F);
            button15.Location = new Point(696, 318);
            button15.Name = "button15";
            button15.Size = new Size(125, 93);
            button15.TabIndex = 19;
            button15.Text = "=";
            button15.UseVisualStyleBackColor = true;
            button15.Click += button15_Click;
            // 
            // button16
            // 
            button16.Font = new Font("Segoe UI", 24F);
            button16.Location = new Point(696, 437);
            button16.Name = "button16";
            button16.Size = new Size(125, 76);
            button16.TabIndex = 20;
            button16.Text = ".";
            button16.UseVisualStyleBackColor = true;
            button16.Click += button16_Click;
            // 
            // button17
            // 
            button17.Location = new Point(558, 432);
            button17.Name = "button17";
            button17.Size = new Size(103, 76);
            button17.TabIndex = 21;
            button17.Text = "x";
            button17.UseVisualStyleBackColor = true;
            button17.Click += button17_Click;
            // 
            // button18
            // 
            button18.Location = new Point(393, 437);
            button18.Name = "button18";
            button18.Size = new Size(113, 76);
            button18.TabIndex = 22;
            button18.Text = "%";
            button18.UseVisualStyleBackColor = true;
            button18.Click += button18_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(55, 33);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(752, 23);
            textBox1.TabIndex = 23;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // button19
            // 
            button19.Location = new Point(55, 447);
            button19.Name = "button19";
            button19.Size = new Size(287, 47);
            button19.TabIndex = 24;
            button19.Text = "limpar";
            button19.UseVisualStyleBackColor = true;
            button19.Click += button19_Click;
            // 
            // button20
            // 
            button20.Location = new Point(558, 528);
            button20.Name = "button20";
            button20.Size = new Size(103, 47);
            button20.TabIndex = 25;
            button20.Text = "√";
            button20.UseVisualStyleBackColor = true;
            button20.Click += button20_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(905, 587);
            Controls.Add(button20);
            Controls.Add(button19);
            Controls.Add(textBox1);
            Controls.Add(button18);
            Controls.Add(button17);
            Controls.Add(button16);
            Controls.Add(button15);
            Controls.Add(button14);
            Controls.Add(button13);
            Controls.Add(button12);
            Controls.Add(button11);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
        private Button button18;
        private TextBox textBox1;
        private Button button19;
        private Button button20;
    }
}
