﻿using System.Diagnostics;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace _08
{
    [DebuggerDisplay($"{{{nameof(GetDebuggerDisplay)}(),nq}}")]
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();


        }
        string input = string.Empty;
        string opand1 = string.Empty;
        string opand2 = string.Empty;
        char opand;
        double result = 0.0;

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            opand1 = input;
            opand = '^';
            input = string.Empty;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            opand1 = input;
            opand = '+';
            input = string.Empty;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            opand1 = input;
            opand = '-';
            input = string.Empty;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            opand1 = input;
            opand = '/';
            input = string.Empty;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.textBox1.Text = "";
            input += "1";
            this.textBox1.Text += input;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.textBox1.Text = "";
            input += "2";
            this.textBox1.Text += input;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.textBox1.Text = "";
            input += "3";
            this.textBox1.Text += input;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.textBox1.Text = "";
            input += "4";
            this.textBox1.Text += input;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.textBox1.Text = "";
            input += "5";
            this.textBox1.Text += input;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.textBox1.Text = "";
            input += "6";
            this.textBox1.Text += input;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            this.textBox1.Text = "";
            input += "7";
            this.textBox1.Text += input;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.textBox1.Text = "";
            input += "8";
            this.textBox1.Text += input;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            this.textBox1.Text = "";
            input += "9";
            this.textBox1.Text += input;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            this.textBox1.Text = "";
            input += "0";
            this.textBox1.Text += input;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            input += ".";
        }

        private void button17_Click(object sender, EventArgs e)
        {
            opand1 = input;
            opand = 'x';
            input = string.Empty;
        }

        private void button18_Click(object sender, EventArgs e)
        {
            opand1 = input;
            opand = '%';
            input = string.Empty;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button19_Click(object sender, EventArgs e)
        {
            this.textBox1.Text = "";
            this.input = string.Empty;
            this.opand1 = string.Empty;
            this.opand2 = string.Empty;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            opand2 = input;
            double num1, num2;
            double.TryParse(opand1, out num1);
            double.TryParse(opand2, out num2);

            if (opand == '+')
            {
                result = num1+num2;
                textBox1.Text = result.ToString();
            }

            else if (opand == '-')
            {
                result = num1 - num2;
                textBox1.Text = result.ToString();
            }

            else if (opand == 'x')
            {
                result = num1 * num2;
                textBox1.Text = result.ToString();
            }

            else if (opand == '/')
            {
                result = num1 / num2;
                textBox1.Text = result.ToString();
            }

            else if (opand == '^')
            {
                result = Math.Pow( num1 ,num2);
                textBox1.Text = result.ToString();
            }

            else if (opand == '%')
            {
                result = num1 % num2;
                textBox1.Text = result.ToString();
            }

            else if (opand == '√')
            {
                result = Math.Sqrt(num1);
                textBox1.Text = result.ToString();
            }
        }

        private string GetDebuggerDisplay()
        {
            return ToString();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            opand1 = input;
            opand = '√';
            input = string.Empty;

        }
    }
}
